import boto3
import os

def lambda_handler(event, context):
    sns_topic_arn = os.environ['SNS_TOPIC_ARN']
    ec2_client = boto3.client('ec2')
    ce_client = boto3.client('ce')
    sns_client = boto3.client('sns')

    # Process EC2 instance termination event
    instance_id = event['detail']['instance-id']

    # Generate billing report (mock example, customize as needed)
    billing_data = f"Billing report for EC2 instance {instance_id}: \nCost: $10 (example cost)."

    # Send the report via SNS
    sns_client.publish(
        TopicArn=sns_topic_arn,
        Subject="EC2 Termination Billing Report",
        Message=billing_data
    )

    return {"statusCode": 200, "body": "Report sent"}
